#!/usr/bin/env python3
"""
Algorithm Server for MDP Project
Exposes endpoints for pathfinding and image processing
"""

from flask import Flask, request, jsonify
import logging
import sys
import os

# Add your project path to sys.path if needed
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

# Import your algorithm (adjust import as needed)
from algo.algo import find_path  # Replace with your actual function

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@app.route('/api/status', methods=['GET'])
def get_status():
    return jsonify({
        "status": "online",
        "service": "MDP Algorithm Server",
        "version": "1.0.0"
    })

@app.route('/api/path', methods=['POST'])
def request_path():
    try:
        data = request.get_json()
        obstacles = data.get('obstacles', [])
        robot_start = data.get('robot_start', {"x": 1, "y": 1, "direction": "N"})
        task = data.get('task', 'path_planning')

        logger.info(f"Received pathfinding request: {data}")

        # Call your algorithm
        path_commands = find_path(obstacles, robot_start)

        response = {
            "status": "success",
            "commands": path_commands,
            "total_commands": len(path_commands)
        }
        return jsonify(response)
    except Exception as e:
        logger.error(f"Error in pathfinding request: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/image', methods=['POST'])
def process_image():
    # Placeholder for image processing
    return jsonify({
        "status": "success",
        "letter": "A",  # Replace with actual result
        "confidence": 0.95
    })

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Endpoint not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    logger.info("Starting Algorithm Server...")
    app.run(host='0.0.0.0', port=8080, debug=True)