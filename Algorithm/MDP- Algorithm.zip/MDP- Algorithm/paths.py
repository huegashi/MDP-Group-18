from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"            # all artifacts live here
UPLOADS_DIR = DATA_DIR / "uploads"
RUNS_DIR = DATA_DIR / "runs"            # Ultralytics "project"
OWN_RESULTS_DIR = DATA_DIR / "own_results"

for p in (DATA_DIR, UPLOADS_DIR, RUNS_DIR, OWN_RESULTS_DIR):
    p.mkdir(parents=True, exist_ok=True)