from ultralytics import YOLO

model = YOLO("C:/Users/gauth/OneDrive - Nanyang Technological University/Documents/SC2079/Week7_best.pt")
model.val(data="C:/Users/gauth/OneDrive - Nanyang Technological University/Documents/SC2079/MDP-FINAL-main_2/MDP-Algorithm/data.yaml", imgsz=640, split="val") 